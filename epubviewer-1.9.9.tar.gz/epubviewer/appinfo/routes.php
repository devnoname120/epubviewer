<?php

declare(strict_types=1);

return ['routes' => [
	// Page
	['name' => 'page#showReader', 'url' => '/', 'verb' => 'GET'],
	['name' => 'public_reader#showReader', 'url' => '/public/{token}', 'verb' => 'GET'],

	// Bookmarks
	['name' => 'bookmark#get_cursor', 'url' => '/bookmark/cursor/{fileId}', 'verb' => 'GET'],
	['name' => 'bookmark#set_cursor', 'url' => '/bookmark/cursor', 'verb' => 'POST'],
	['name' => 'bookmark#delete_cursor', 'url' => '/bookmark/cursor/{fileId}', 'verb' => 'DELETE'],
	['name' => 'bookmark#get', 'url' => '/bookmark/{fileId}/{name}', 'verb' => 'GET', 'defaults' => ['name' => '']],
	['name' => 'bookmark#get', 'url' => '/bookmark/{fileId}/{type}/{name}', 'verb' => 'GET', 'defaults' => ['name' => '']],
	['name' => 'bookmark#set', 'url' => '/bookmark', 'verb' => 'POST'],
	['name' => 'bookmark#delete', 'url' => '/bookmark/{fileId}/{name}', 'verb' => 'DELETE'],

	// Preferences
	['name' => 'preference#get_default', 'url' => '/preference/default/{scope}/{name}', 'verb' => 'GET', 'defaults' => ['name' => '']],
	['name' => 'preference#set_default', 'url' => '/preference/default', 'verb' => 'POST'],
	['name' => 'preference#delete_default', 'url' => '/preference/default/{scope}/{name}', 'verb' => 'DELETE'],
	['name' => 'preference#get', 'url' => '/preference/{fileId}/{scope}/{name}', 'verb' => 'GET', 'defaults' => ['name' => '']],
	['name' => 'preference#set', 'url' => '/preference', 'verb' => 'POST'],
	['name' => 'preference#delete', 'url' => '/preference/{fileId}/{scope}/{name}', 'verb' => 'DELETE'],

	// User Settings
	['name' => 'settings#setPreference', 'url' => '/settings/set', 'verb' => 'POST'],
]];
