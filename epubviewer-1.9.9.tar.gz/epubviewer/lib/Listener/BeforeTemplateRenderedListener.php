<?php

declare(strict_types=1);

namespace OCA\Epubviewer\Listener;

use OCA\Epubviewer\AppInfo\Application;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Services\IInitialState;
use OCP\Config\IUserConfig;
use OCP\EventDispatcher\Event;
use OCP\EventDispatcher\IEventListener;
use OCP\IUserSession;

/** @template-implements IEventListener<\OCP\AppFramework\Http\Events\BeforeTemplateRenderedEvent> */
class BeforeTemplateRenderedListener implements IEventListener {
	public function __construct(
		private IInitialState $initialState,
		private IUserSession $userSession,
		private IUserConfig $config,
	) {
	}

	public function handle(Event $event): void {
		/** @var \OCP\AppFramework\Http\Events\BeforeTemplateRenderedEvent $event */
		$renderAs = $event->getResponse()->getRenderAs();
		if ($renderAs !== TemplateResponse::RENDER_AS_USER && $renderAs !== TemplateResponse::RENDER_AS_GUEST) {
			return;
		}

		$this->initialState->provideLazyInitialState('enableEpub', function () {
			$user = $this->userSession->getUser();
			if ($user !== null) {
				$uid = $user->getUID();
				return $this->config->getValueString($uid, Application::APP_ID, 'epub_enable', 'true') === 'true';
			}
			return true;
		});

		$this->initialState->provideLazyInitialState('enablePdf', function () {
			$user = $this->userSession->getUser();
			if ($user !== null) {
				$uid = $user->getUID();
				return $this->config->getValueString($uid, Application::APP_ID, 'pdf_enable', 'false') === 'true';
			}
			return false;
		});

		$this->initialState->provideLazyInitialState('enableCbx', function () {
			$user = $this->userSession->getUser();
			if ($user !== null) {
				$uid = $user->getUID();
				return $this->config->getValueString($uid, Application::APP_ID, 'cbx_enable', 'true') === 'true';
			}
			return true;
		});
	}
}
