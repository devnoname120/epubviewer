<?php

// Maintainer's note:
// ---
// This file is a copy-paste from the nextcloud/server repository, moved to the OCA namespace, because we need it, but it's in the private \OC\Preview namespace.
// https://github.com/nextcloud/server/blob/0e070bb5bb2e5370d57d82143a792c02f009f69b/lib/private/Preview/ProviderV2.php
// ---

declare(strict_types=1);

/**
 * SPDX-FileCopyrightText: 2019 Nextcloud GmbH and Nextcloud contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */

namespace OCA\Epubviewer\Preview;

use OCP\Files\File;
use OCP\Files\FileInfo;
use OCP\IImage;
use OCP\ITempManager;
use OCP\Preview\IProviderV2;
use OCP\Server;
use Psr\Log\LoggerInterface;

abstract class ProviderV2 implements IProviderV2 {
	protected array $tmpFiles = [];

	public function __construct(
		protected array $options = [],
	) {
	}

	/**
	 * @return string Regex with the mimetypes that are supported by this provider
	 */
	#[\Override]
	abstract public function getMimeType(): string ;

	/**
	 * Check if a preview can be generated for $path
	 *
	 * @param FileInfo $file
	 * @return bool
	 */
	#[\Override]
	public function isAvailable(FileInfo $file): bool {
		return true;
	}

	/**
	 * get thumbnail for file at path $path
	 *
	 * @param File $file
	 * @param int $maxX The maximum X size of the thumbnail. It can be smaller depending on the shape of the image
	 * @param int $maxY The maximum Y size of the thumbnail. It can be smaller depending on the shape of the image
	 * @return null|IImage null if no preview was generated
	 * @since 17.0.0
	 */
	#[\Override]
	abstract public function getThumbnail(File $file, int $maxX, int $maxY): ?IImage;

	protected function useTempFile(File $file): bool {
		return $file->isEncrypted() || !$file->getStorage()->isLocal();
	}

	/**
	 * Get a path to either the local file or temporary file
	 *
	 * @param File $file
	 * @param ?int $maxSize maximum size for temporary files
	 */
	protected function getLocalFile(File $file, ?int $maxSize = null): string|false {
		if ($this->useTempFile($file)) {
			$absPath = Server::get(ITempManager::class)->getTemporaryFile();

			if ($absPath === false) {
				Server::get(LoggerInterface::class)->error(
					'Failed to get local file to generate thumbnail for: ' . $file->getPath(),
					['app' => 'core']
				);
				return false;
			}

			$content = $file->fopen('r');
			if ($content === false) {
				return false;
			}

			if ($maxSize !== null && $maxSize !== 0) {
				$content = stream_get_contents($content, $maxSize);
			}

			file_put_contents($absPath, $content);
			$this->tmpFiles[] = $absPath;
			return $absPath;
		} else {
			$path = $file->getStorage()->getLocalFile($file->getInternalPath());
			if (is_string($path)) {
				return $path;
			} else {
				return false;
			}
		}
	}

	/**
	 * Clean any generated temporary files
	 */
	protected function cleanTmpFiles(): void {
		foreach ($this->tmpFiles as $tmpFile) {
			unlink($tmpFile);
		}

		$this->tmpFiles = [];
	}
}
